#ifndef _REACTION_GAME_H
#define _REACTION_GAME_H

void reaction_game_run(void);
void test(void);

#endif